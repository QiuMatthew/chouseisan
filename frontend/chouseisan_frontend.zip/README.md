# Chouseisan like scheduler

## Usage

install dependency first:

```bash
npm install
```

build:

```bash
npm run build
```

host locally for development

```bash
npm start
```

run mock-api

```bash
npm run mock-api
```

**Please do NOT commit the `package.json` file if you changed the proxy!**
